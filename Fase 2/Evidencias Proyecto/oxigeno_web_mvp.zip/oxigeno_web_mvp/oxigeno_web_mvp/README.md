# O₂ Logística Predictiva — MVP local

Aplicación Flask para el Proyecto APT:

- creación de cuentas;
- login y cambio de contraseña;
- Argon2id para passwords;
- HMAC-SHA256 para identificador fuente;
- cifrado AES-256-GCM para identidad y ubicación;
- importación exclusiva de un CSV `HISTORICO` o `COLD_START`;
- selección automática de estrategia predictiva;
- integración con artefactos `.joblib`;
- consulta de pacientes, predicciones y ruta;
- desvinculación irreversible de identidad;
- mapa general de Chile;
- visualización individual de ubicación;
- rutas por comuna de máximo 25 pacientes;
- carga sugerida de cilindros por ruta;
- Google Geocoding + Routes API;
- acceso MariaDB exclusivamente mediante procedimientos almacenados.

## Arquitectura

```text
Browser
  |
  v
Flask
  |-- Auth / CSV / ML / Rutas
  |-- Argon2id
  |-- HMAC-SHA256
  |-- AES-256-GCM
  |
  +---- conexión oxigeno_app ------> MariaDB (zona analítica)
  |
  +---- conexión oxigeno_vault ----> MariaDB (bóveda)
  |
  +---- Google Geocoding / Routes API
  |
  +---- modelos joblib
```

## 1. XAMPP

Enciende **MySQL** desde XAMPP.

Importa primero:

`oxigeno_logistica_segura_v2.sql`

## 2. Crear dos usuarios MariaDB

En phpMyAdmin > Cuentas de usuario crea:

- `oxigeno_app` @ `localhost`
- `oxigeno_vault` @ `localhost`

Usa contraseñas distintas y aleatorias.

No uses `root` desde Flask.

Después ejecuta:

`sql/grants.sql`

Este archivo solo concede `EXECUTE`; no contiene ninguna contraseña.

## 3. Entorno Python

Windows:

```bat
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 4. Generar secretos

```bat
python scripts_generate_secrets.py
```

Copia `.env.example` a `.env` y reemplaza sus placeholders con los secretos generados.

También agrega las contraseñas de MariaDB elegidas en phpMyAdmin.

`.env` está excluido de Git.

## 5. Modelos

Copia a `models/`:

```text
modelo_cantidad_cilindros.joblib
modelo_proxima_entrega.joblib
modelo_cold_start.joblib
```

## 6. Google Maps

Habilita en Google Cloud:

- Maps JavaScript API
- Geocoding API
- Routes API

Usa **dos claves**:

### `GOOGLE_MAPS_BROWSER_KEY`

Solo para Maps JavaScript API.

Restringir por HTTP referrer, por ejemplo durante desarrollo:

```text
http://127.0.0.1:5000/*
http://localhost:5000/*
```

### `GOOGLE_MAPS_SERVER_KEY`

Solo para:

- Geocoding API
- Routes API

No se expone al navegador.

Configura también la base logística:

```env
DEPOT_LAT=...
DEPOT_LNG=...
DEPOT_LABEL=Centro de distribución
```

El sistema usa la base como origen y destino y hasta 25 pacientes como
waypoints intermedios.

## 7. Ejecutar

```bat
python run.py
```

Abrir:

```text
http://127.0.0.1:5000
```

XAMPP se utiliza para MariaDB; Flask sirve la aplicación web local.

## CSV Cold Start

Requerido:

```text
ID,Edad,Comunas,Sexo
```

También se acepta `Comuna`.

Opcional:

```text
Direccion,Nombre,Apellido,Contacto
```

Los campos opcionales personales se cifran antes de llegar a MariaDB.

## CSV histórico

Se detecta cuando existen:

```text
ID
Edad
Comunas/Comuna
Sexo
Suma_total
meses_activos
n_despachos
intervalo_median
```

y al menos tres columnas mensuales.

## Importante sobre el modelo histórico de fecha

El `modelo_proxima_entrega.joblib` que se desarrolló previamente usa intervalos
recientes `lag_1..lag_5`.

`dataset_completo_cruzado.csv` no contiene esos cinco intervalos.

Por tanto, con el requisito actual de **solo dos tipos de CSV**, el backend:

1. intenta usar el modelo histórico si esas features están presentes;
2. si no están, usa `intervalo_median` como estimación histórica y registra
   explícitamente el modelo como `INTERVALO_MEDIAN_FALLBACK`;
3. nunca etiqueta ese fallback como una predicción ML.

Esto evita inventar datos que el CSV no contiene.

## Privacidad

El identificador original:

```text
ID -> HMAC-SHA256 + pepper -> identificador_hash
```

Nunca se almacena en claro.

La información recuperable:

```text
nombre / contacto / dirección / coordenadas
```

se cifra con AES-256-GCM.

La zona analítica utiliza exclusivamente el UUID seudónimo.

La opción **Eliminar identidad** borra la fila de la bóveda y deja los datos
analíticos desvinculados.

## Rutas

Los pacientes sin ruta se agrupan por comuna:

```text
63 pacientes Santiago
-> Ruta 1: 25
-> Ruta 2: 25
-> Ruta 3: 13
```

Si todos los pacientes de una ruta tienen coordenadas disponibles y Google
Routes está configurado, se optimiza el orden de visita.

Si falta una dirección, el sistema conserva la ruta pero no inventa coordenadas.

## Pruebas

```bat
pip install pytest
pytest -q
```
