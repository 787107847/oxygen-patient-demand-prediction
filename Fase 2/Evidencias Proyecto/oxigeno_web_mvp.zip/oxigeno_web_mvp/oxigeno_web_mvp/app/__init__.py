from dotenv import load_dotenv
load_dotenv()

from flask import Flask
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

from .config import Config
from .auth import auth_bp, load_user_by_username
from .main import main_bp
from .imports import imports_bp
from .patients import patients_bp
from .routes import routes_bp

login_manager = LoginManager()
csrf = CSRFProtect()

def create_app():
    Config.validate()

    app = Flask(__name__)
    app.config.from_object(Config)

    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Inicia sesión para continuar."

    csrf.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return load_user_by_username(user_id)

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(imports_bp)
    app.register_blueprint(patients_bp)
    app.register_blueprint(routes_bp)

    return app
