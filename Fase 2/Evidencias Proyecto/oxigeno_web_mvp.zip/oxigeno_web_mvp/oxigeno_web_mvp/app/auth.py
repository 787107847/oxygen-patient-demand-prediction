from dataclasses import dataclass
from datetime import datetime, timezone
from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import UserMixin, current_user, login_user, logout_user, login_required

from .db import call_proc, first_row
from .security import (
    hash_email,
    password_hash,
    password_verify,
    validate_password,
)

auth_bp = Blueprint("auth", __name__, url_prefix="/auth")

@dataclass
class AppUser(UserMixin):
    id_usuario: int
    username: str
    role: str
    active: bool = True

    def get_id(self):
        return self.username

    @property
    def is_active(self):
        return bool(self.active)

def load_user_by_username(username):
    try:
        _, sets = call_proc("sp_usuario_obtener_auth", (username,))
        row = first_row(sets)
        if not row:
            return None
        return AppUser(
            id_usuario=row["id_usuario"],
            username=row["username"],
            role=row["rol"],
            active=bool(row["activo"]),
        )
    except Exception:
        return None

@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not username:
            flash("El nombre de usuario es obligatorio.", "danger")
            return render_template("register.html")

        if password != confirm:
            flash("Las contraseñas no coinciden.", "danger")
            return render_template("register.html")

        ok, msg = validate_password(password)
        if not ok:
            flash(msg, "danger")
            return render_template("register.html")

        try:
            call_proc(
                "sp_usuario_crear",
                (
                    username,
                    hash_email(email) if email else None,
                    password_hash(password),
                ),
            )
            flash("Cuenta creada correctamente. Ya puedes iniciar sesión.", "success")
            return redirect(url_for("auth.login"))
        except Exception as exc:
            flash(f"No fue posible crear la cuenta: {exc}", "danger")

    return render_template("register.html")

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")

        try:
            _, sets = call_proc("sp_usuario_obtener_auth", (username,))
            row = first_row(sets)

            if not row:
                flash("Credenciales inválidas.", "danger")
                return render_template("login.html")

            blocked_until = row.get("bloqueado_hasta")
            if blocked_until and blocked_until > datetime.now():
                flash("Cuenta bloqueada temporalmente por intentos fallidos.", "danger")
                return render_template("login.html")

            valid = bool(row["activo"]) and password_verify(
                row["password_hash"], password
            )

            call_proc(
                "sp_usuario_registrar_login",
                (row["id_usuario"], valid),
            )

            if not valid:
                flash("Credenciales inválidas.", "danger")
                return render_template("login.html")

            user = AppUser(
                id_usuario=row["id_usuario"],
                username=row["username"],
                role=row["rol"],
                active=bool(row["activo"]),
            )
            login_user(user)
            return redirect(url_for("main.dashboard"))

        except Exception as exc:
            flash(f"No fue posible iniciar sesión: {exc}", "danger")

    return render_template("login.html")

@auth_bp.route("/logout", methods=["POST"])
@login_required
def logout():
    logout_user()
    flash("Sesión cerrada.", "info")
    return redirect(url_for("auth.login"))

@auth_bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")

        if new_password != confirm:
            flash("Las contraseñas nuevas no coinciden.", "danger")
            return render_template("change_password.html")

        ok, msg = validate_password(new_password)
        if not ok:
            flash(msg, "danger")
            return render_template("change_password.html")

        try:
            _, sets = call_proc(
                "sp_usuario_obtener_auth",
                (current_user.username,),
            )
            row = first_row(sets)

            if not row or not password_verify(row["password_hash"], current_password):
                flash("La contraseña actual es incorrecta.", "danger")
                return render_template("change_password.html")

            call_proc(
                "sp_usuario_cambiar_password",
                (row["id_usuario"], password_hash(new_password)),
            )
            flash("Contraseña actualizada correctamente.", "success")
            return redirect(url_for("main.dashboard"))

        except Exception as exc:
            flash(f"No fue posible cambiar la contraseña: {exc}", "danger")

    return render_template("change_password.html")
