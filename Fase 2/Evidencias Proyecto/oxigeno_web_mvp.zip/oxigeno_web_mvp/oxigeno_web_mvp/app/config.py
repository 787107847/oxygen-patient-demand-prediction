import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

class Config:
    SECRET_KEY = os.environ.get("FLASK_SECRET_KEY", "")

    MAX_CONTENT_LENGTH = int(
        float(os.environ.get("MAX_CONTENT_LENGTH_MB", "15")) * 1024 * 1024
    )

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "false").lower() == "true"

    DB_HOST = os.environ.get("DB_HOST", "127.0.0.1")
    DB_PORT = int(os.environ.get("DB_PORT", "3306"))
    DB_NAME = os.environ.get("DB_NAME", "oxigeno_logistica")
    DB_APP_USER = os.environ.get("DB_APP_USER", "")
    DB_APP_PASSWORD = os.environ.get("DB_APP_PASSWORD", "")
    DB_VAULT_USER = os.environ.get("DB_VAULT_USER", "")
    DB_VAULT_PASSWORD = os.environ.get("DB_VAULT_PASSWORD", "")

    IDENTIFIER_HMAC_PEPPER = os.environ.get("IDENTIFIER_HMAC_PEPPER", "")
    DATA_ENCRYPTION_KEY = os.environ.get("DATA_ENCRYPTION_KEY", "")
    DATA_KEY_VERSION = int(os.environ.get("DATA_KEY_VERSION", "1"))

    GOOGLE_MAPS_BROWSER_KEY = os.environ.get("GOOGLE_MAPS_BROWSER_KEY", "")
    GOOGLE_MAPS_SERVER_KEY = os.environ.get("GOOGLE_MAPS_SERVER_KEY", "")

    DEPOT_LAT = os.environ.get("DEPOT_LAT", "")
    DEPOT_LNG = os.environ.get("DEPOT_LNG", "")
    DEPOT_LABEL = os.environ.get("DEPOT_LABEL", "Centro de distribución")

    MODEL_QUANTITY = os.environ.get(
        "MODEL_QUANTITY",
        str(BASE_DIR / "models" / "modelo_cantidad_cilindros.joblib"),
    )
    MODEL_TIMING = os.environ.get(
        "MODEL_TIMING",
        str(BASE_DIR / "models" / "modelo_proxima_entrega.joblib"),
    )
    MODEL_COLD_START = os.environ.get(
        "MODEL_COLD_START",
        str(BASE_DIR / "models" / "modelo_cold_start.joblib"),
    )

    @classmethod
    def validate(cls):
        required = {
            "FLASK_SECRET_KEY": cls.SECRET_KEY,
            "DB_APP_USER": cls.DB_APP_USER,
            "DB_APP_PASSWORD": cls.DB_APP_PASSWORD,
            "DB_VAULT_USER": cls.DB_VAULT_USER,
            "DB_VAULT_PASSWORD": cls.DB_VAULT_PASSWORD,
            "IDENTIFIER_HMAC_PEPPER": cls.IDENTIFIER_HMAC_PEPPER,
            "DATA_ENCRYPTION_KEY": cls.DATA_ENCRYPTION_KEY,
        }
        missing = [k for k, v in required.items() if not v]
        if missing:
            raise RuntimeError(
                "Faltan variables obligatorias en .env: " + ", ".join(missing)
            )
