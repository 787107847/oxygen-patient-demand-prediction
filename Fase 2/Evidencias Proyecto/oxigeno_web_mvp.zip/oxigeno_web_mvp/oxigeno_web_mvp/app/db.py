import mysql.connector
from flask import current_app

def _connection(role="app"):
    if role == "vault":
        user = current_app.config["DB_VAULT_USER"]
        password = current_app.config["DB_VAULT_PASSWORD"]
    else:
        user = current_app.config["DB_APP_USER"]
        password = current_app.config["DB_APP_PASSWORD"]

    return mysql.connector.connect(
        host=current_app.config["DB_HOST"],
        port=current_app.config["DB_PORT"],
        database=current_app.config["DB_NAME"],
        user=user,
        password=password,
        autocommit=False,
        charset="utf8mb4",
    )

def _rows_to_dicts(result_cursor):
    columns = list(result_cursor.column_names or ())
    rows = result_cursor.fetchall()

    if not columns:
        return rows

    return [
        dict(zip(columns, row))
        for row in rows
    ]

def call_proc(name, args=(), role="app"):
    cnx = _connection(role)

    # callproc() se ejecuta con cursor normal.
    # Luego convertimos manualmente los result sets a diccionarios.
    cursor = cnx.cursor()

    try:
        returned_args = cursor.callproc(name, args)

        result_sets = []

        for result in cursor.stored_results():
            result_sets.append(
                _rows_to_dicts(result)
            )

        cnx.commit()
        return returned_args, result_sets

    except Exception:
        cnx.rollback()
        raise

    finally:
        cursor.close()
        cnx.close()

def first_row(result_sets, set_index=0):
    if not result_sets:
        return None

    if len(result_sets) <= set_index:
        return None

    rows = result_sets[set_index]

    return rows[0] if rows else None
