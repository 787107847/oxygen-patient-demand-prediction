from datetime import date, timedelta
import pandas as pd
from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from .db import call_proc
from .security import sha256_bytes
from .services.csv_service import (
    detect_dataset_type,
    normalize_row,
    parse_csv_bytes,
)
from .services.model_service import ModelService
from .services.patient_service import PatientService

imports_bp = Blueprint("imports", __name__, url_prefix="/imports")

@imports_bp.route("/", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        upload_file = request.files.get("csv_file")

        if not upload_file or not upload_file.filename:
            flash("Selecciona un archivo CSV.", "danger")
            return render_template("import.html")

        if not upload_file.filename.lower().endswith(".csv"):
            flash("Solo se admiten archivos .csv.", "danger")
            return render_template("import.html")

        raw = upload_file.read()
        filename = secure_filename(upload_file.filename)

        try:
            df = parse_csv_bytes(raw)
            dataset_type = detect_dataset_type(df)
        except Exception as exc:
            flash(f"CSV rechazado: {exc}", "danger")
            return render_template("import.html")

        try:
            out_args, _ = call_proc(
                "sp_importacion_crear",
                (
                    current_user.id_usuario,
                    sha256_bytes(raw),
                    dataset_type,
                    0,
                ),
            )
            import_id = int(out_args[-1])

            model_service = ModelService()
            patient_service = PatientService()

            ok = 0
            errors = []

            for index, series in df.iterrows():
                try:
                    row = normalize_row(series)

                    if not row["id"]:
                        raise ValueError("ID vacío")
                    if row["edad"] is None:
                        raise ValueError("Edad inválida")
                    if not row["comuna"]:
                        raise ValueError("Comuna vacía")
                    if not row["sexo"]:
                        raise ValueError("Sexo vacío")

                    token, _ = patient_service.register_from_row(
                        row,
                        dataset_type,
                    )

                    if dataset_type == "HISTORICO":
                        meses = int(float(series.get("meses_activos", 0) or 0))
                        despachos = int(float(series.get("n_despachos", 0) or 0))
                        call_proc(
                            "sp_paciente_actualizar_resumen_historial",
                            (token, meses, despachos),
                        )

                    prediction_input = series.to_dict()
                    prediction_input.update(row)

                    prediction = model_service.predict(
                        dataset_type,
                        prediction_input,
                    )

                    estimated_date = (
                        date.today()
                        + timedelta(days=int(prediction["days"]))
                    )

                    call_proc(
                        "sp_prediccion_guardar",
                        (
                            token,
                            prediction["quantity_strategy"],
                            prediction["timing_strategy"],
                            int(prediction["quantity"]),
                            int(prediction["days"]),
                            estimated_date,
                            prediction["range"],
                            prediction.get("confidence"),
                            prediction["quantity_model"],
                            prediction["timing_model"],
                        ),
                    )

                    ok += 1

                except Exception as exc:
                    errors.append(
                        {
                            "row": int(index) + 2,
                            "error": str(exc),
                        }
                    )

            final_state = "COMPLETADO" if not errors else "COMPLETADO_CON_ERRORES"

            call_proc(
                "sp_importacion_finalizar",
                (
                    import_id,
                    int(len(df)),
                    ok,
                    len(errors),
                    final_state,
                ),
            )

            flash(
                f"{dataset_type}: {ok}/{len(df)} pacientes procesados.",
                "success" if not errors else "warning",
            )

            return render_template(
                "import_result.html",
                dataset_type=dataset_type,
                filename=filename,
                total=len(df),
                ok=ok,
                errors=errors[:50],
                import_id=import_id,
            )

        except Exception as exc:
            flash(f"Error durante la importación: {exc}", "danger")

    return render_template("import.html")
