from flask import Blueprint, render_template
from flask_login import login_required

from .db import call_proc
from .services.model_service import ModelService

main_bp = Blueprint("main", __name__)

@main_bp.route("/")
@login_required
def dashboard():
    _, patient_sets = call_proc("sp_pacientes_listar")
    patients = patient_sets[0] if patient_sets else []

    _, route_sets = call_proc("sp_rutas_listar")
    routes = route_sets[0] if route_sets else []

    total_cylinders = sum(
        int(r.get("total_cilindros") or 0)
        for r in routes
    )

    return render_template(
        "dashboard.html",
        patient_count=len(patients),
        route_count=len(routes),
        cylinder_count=total_cylinders,
        models=ModelService().status(),
    )
