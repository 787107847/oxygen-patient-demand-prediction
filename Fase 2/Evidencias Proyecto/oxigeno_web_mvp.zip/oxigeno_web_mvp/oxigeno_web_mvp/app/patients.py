from flask import Blueprint, abort, flash, jsonify, redirect, render_template, url_for, current_app
from flask_login import login_required

from .db import call_proc
from .services.patient_service import PatientService

patients_bp = Blueprint("patients", __name__, url_prefix="/patients")

@patients_bp.route("/")
@login_required
def list_patients():
    _, sets = call_proc("sp_pacientes_listar")
    rows = sets[0] if sets else []
    return render_template("patients.html", patients=rows)

@patients_bp.route("/<token>/map")
@login_required
def patient_map(token):
    secure = PatientService().secure_location(token)
    location = (secure or {}).get("location")

    if not secure or not location:
        flash("Este paciente no tiene una ubicación geocodificada disponible.", "warning")
        return redirect(url_for("patients.list_patients"))

    return render_template(
        "patient_map.html",
        token=token,
        address=secure.get("address"),
        location=location,
        maps_key=current_app.config["GOOGLE_MAPS_BROWSER_KEY"],
    )

@patients_bp.route("/<token>/unlink", methods=["POST"])
@login_required
def unlink_identity(token):
    try:
        PatientService().unlink_identity(token)
        flash(
            "La información de identidad fue eliminada de la bóveda. "
            "Los datos analíticos permanecen desvinculados.",
            "success",
        )
    except Exception as exc:
        flash(f"No fue posible desvincular la identidad: {exc}", "danger")

    return redirect(url_for("patients.list_patients"))
