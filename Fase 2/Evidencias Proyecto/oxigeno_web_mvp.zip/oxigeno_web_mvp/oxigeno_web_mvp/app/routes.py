from datetime import date
from flask import Blueprint, current_app, flash, jsonify, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from .db import call_proc
from .services.routing_service import RoutingService

routes_bp = Blueprint("routes", __name__, url_prefix="/routes")

@routes_bp.route("/")
@login_required
def list_routes():
    _, sets = call_proc("sp_rutas_listar")
    rows = sets[0] if sets else []
    return render_template("routes.html", routes=rows)

@routes_bp.route("/generate", methods=["POST"])
@login_required
def generate():
    planned_date = request.form.get("planned_date", "").strip()

    if not planned_date:
        flash("Selecciona una fecha de planificación.", "danger")
        return redirect(url_for("routes.list_routes"))

    try:
        created = RoutingService().generate_for_unrouted(
            planned_date,
            current_user.id_usuario,
        )

        if not created:
            flash(
                "No hay pacientes sin ruta y con predicción disponible.",
                "info",
            )
        else:
            optimized = sum(1 for item in created if item["google_optimized"])
            flash(
                f"Se crearon {len(created)} rutas. "
                f"{optimized} fueron optimizadas con Google Routes.",
                "success",
            )
    except Exception as exc:
        flash(f"No fue posible generar las rutas: {exc}", "danger")

    return redirect(url_for("routes.list_routes"))

@routes_bp.route("/<int:route_id>")
@login_required
def detail(route_id):
    _, sets = call_proc("sp_ruta_obtener", (route_id,))
    if not sets or not sets[0]:
        flash("Ruta no encontrada.", "danger")
        return redirect(url_for("routes.list_routes"))

    return render_template(
        "route_detail.html",
        route=sets[0][0],
        patients=sets[1] if len(sets) > 1 else [],
        maps_key=current_app.config["GOOGLE_MAPS_BROWSER_KEY"],
    )

@routes_bp.route("/<int:route_id>/map-data")
@login_required
def map_data(route_id):
    data = RoutingService().route_map_data(route_id)
    if not data:
        return jsonify({"error": "Ruta no encontrada"}), 404
    return jsonify(data)
