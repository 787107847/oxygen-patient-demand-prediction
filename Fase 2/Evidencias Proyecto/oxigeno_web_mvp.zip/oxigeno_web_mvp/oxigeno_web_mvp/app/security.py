import base64
import hashlib
import hmac
import json
import re
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, InvalidHashError
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from flask import current_app

_password_hasher = PasswordHasher()

def password_hash(password: str) -> str:
    return _password_hasher.hash(password)

def password_verify(stored_hash: str, password: str) -> bool:
    try:
        return _password_hasher.verify(stored_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False

def password_needs_rehash(stored_hash: str) -> bool:
    try:
        return _password_hasher.check_needs_rehash(stored_hash)
    except InvalidHashError:
        return True

def validate_password(password: str):
    if len(password) < 10:
        return False, "La contraseña debe tener al menos 10 caracteres."
    if not re.search(r"[A-Za-z]", password):
        return False, "La contraseña debe incluir al menos una letra."
    if not re.search(r"\d", password):
        return False, "La contraseña debe incluir al menos un número."
    return True, ""

def normalize_identifier(value) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if text.endswith(".0"):
        head = text[:-2]
        if head.isdigit():
            text = head
    return text

def hmac_identifier(value: str) -> str:
    normalized = normalize_identifier(value)
    if not normalized:
        raise ValueError("Identificador vacío.")

    key = current_app.config["IDENTIFIER_HMAC_PEPPER"].encode("utf-8")
    return hmac.new(
        key,
        normalized.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

def hash_email(email: str):
    if not email:
        return None
    return hmac_identifier(email.strip().lower())

def _aes():
    key_b64 = current_app.config["DATA_ENCRYPTION_KEY"]
    try:
        key = base64.b64decode(key_b64, validate=True)
    except Exception as exc:
        raise RuntimeError("DATA_ENCRYPTION_KEY no es Base64 válido.") from exc

    if len(key) != 32:
        raise RuntimeError("DATA_ENCRYPTION_KEY debe representar exactamente 32 bytes.")
    return AESGCM(key)

def encrypt_text(value):
    if value is None:
        return None

    text = str(value).strip()
    if not text:
        return None

    import os
    nonce = os.urandom(12)
    encrypted = _aes().encrypt(nonce, text.encode("utf-8"), b"oxygen-v1")
    return nonce + encrypted

def decrypt_text(blob):
    if blob is None:
        return None

    data = bytes(blob)
    if len(data) < 13:
        raise ValueError("Ciphertext inválido.")

    nonce = data[:12]
    ciphertext = data[12:]
    plain = _aes().decrypt(nonce, ciphertext, b"oxygen-v1")
    return plain.decode("utf-8")

def encrypt_json(value):
    if value is None:
        return None
    return encrypt_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")))

def decrypt_json(blob):
    text = decrypt_text(blob)
    return json.loads(text) if text else None

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
