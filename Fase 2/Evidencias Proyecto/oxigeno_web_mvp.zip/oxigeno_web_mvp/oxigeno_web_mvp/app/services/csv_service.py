import io
import re
import unicodedata
import pandas as pd

BASIC_COLUMNS = {"id", "edad", "comuna", "sexo"}
MONTHS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov"]

ALIASES = {
    "id": "id",
    "edad": "edad",
    "sexo": "sexo",
    "comuna": "comuna",
    "comunas": "comuna",
    "direccion": "direccion",
    "dirección": "direccion",
    "nombre": "nombre",
    "apellido": "apellido",
    "contacto": "contacto",
    "suma_total": "suma_total",
    "meses_activos": "meses_activos",
    "n_despachos": "n_despachos",
    "intervalo_median": "intervalo_median",
    "cv_intervalo": "cv_intervalo",
}

def _simple_name(value):
    text = unicodedata.normalize("NFKD", str(value).strip())
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower()
    text = re.sub(r"\s+", "_", text)
    return text

def normalize_columns(df):
    mapping = {}
    for col in df.columns:
        simple = _simple_name(col)
        mapping[col] = ALIASES.get(simple, simple)

    out = df.rename(columns=mapping).copy()
    return out

def parse_csv_bytes(data: bytes):
    last_error = None

    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            text = data.decode(encoding)
            df = pd.read_csv(io.StringIO(text), sep=None, engine="python")
            return normalize_columns(df)
        except Exception as exc:
            last_error = exc

    raise ValueError(f"No fue posible leer el CSV: {last_error}")

def detect_dataset_type(df):
    cols = set(df.columns)

    missing = BASIC_COLUMNS - cols
    if missing:
        raise ValueError(
            "Faltan columnas básicas: " + ", ".join(sorted(missing))
        )

    history_markers = {
        "suma_total",
        "meses_activos",
        "n_despachos",
        "intervalo_median",
    }

    month_count = sum(1 for month in MONTHS if month in cols)

    if history_markers.issubset(cols) and month_count >= 3:
        return "HISTORICO"

    if not history_markers.intersection(cols) and month_count == 0:
        return "COLD_START"

    raise ValueError(
        "El archivo mezcla parcialmente estructuras HISTORICO y COLD_START. "
        "Sube un solo tipo de dataset."
    )

def normalize_row(row):
    result = row.to_dict()

    result["id"] = str(result.get("id", "")).strip()
    if result["id"].endswith(".0") and result["id"][:-2].isdigit():
        result["id"] = result["id"][:-2]

    try:
        result["edad"] = int(float(result.get("edad")))
    except Exception:
        result["edad"] = None

    for key in ("sexo", "comuna"):
        value = result.get(key)
        result[key] = str(value).strip().upper() if pd.notna(value) else ""

    for key in ("direccion", "nombre", "apellido", "contacto"):
        value = result.get(key)
        if value is None or pd.isna(value):
            result[key] = None
        else:
            value = str(value).strip()
            result[key] = value or None

    return result
