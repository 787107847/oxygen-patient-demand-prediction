import json
from urllib.parse import quote
import requests
from flask import current_app

class MapsService:
    def __init__(self):
        self.server_key = current_app.config["GOOGLE_MAPS_SERVER_KEY"]

    def configured(self):
        return bool(self.server_key)

    def depot(self):
        lat = current_app.config["DEPOT_LAT"]
        lng = current_app.config["DEPOT_LNG"]

        if not lat or not lng:
            return None

        return {
            "lat": float(lat),
            "lng": float(lng),
            "label": current_app.config["DEPOT_LABEL"],
        }

    def geocode(self, address, comuna=None):
        if not self.server_key or not address:
            return None

        query = address.strip()
        if comuna and comuna.upper() not in query.upper():
            query += f", {comuna}"
        if "CHILE" not in query.upper():
            query += ", Chile"

        url = (
            "https://geocode.googleapis.com/v4/geocode/address/"
            + quote(query, safe="")
        )

        response = requests.get(
            url,
            headers={
                "X-Goog-Api-Key": self.server_key,
                "X-Goog-FieldMask": (
                    "results.location,"
                    "results.formattedAddress,"
                    "results.placeId,"
                    "results.granularity"
                ),
            },
            timeout=15,
        )
        response.raise_for_status()
        payload = response.json()

        results = payload.get("results", [])
        if not results:
            return None

        best = results[0]
        loc = best.get("location") or {}

        if "latitude" not in loc or "longitude" not in loc:
            return None

        return {
            "lat": float(loc["latitude"]),
            "lng": float(loc["longitude"]),
            "formatted_address": best.get("formattedAddress", query),
            "place_id": best.get("placeId"),
            "granularity": best.get("granularity"),
        }

    def compute_route(self, points, optimize=True):
        """
        points: lista de dicts con lat/lng/token.
        La base logística se usa como origen y destino.
        """
        depot = self.depot()
        if not self.server_key or not depot or not points:
            return None

        intermediates = [
            {
                "location": {
                    "latLng": {
                        "latitude": float(p["lat"]),
                        "longitude": float(p["lng"]),
                    }
                }
            }
            for p in points
        ]

        body = {
            "origin": {
                "location": {
                    "latLng": {
                        "latitude": depot["lat"],
                        "longitude": depot["lng"],
                    }
                }
            },
            "destination": {
                "location": {
                    "latLng": {
                        "latitude": depot["lat"],
                        "longitude": depot["lng"],
                    }
                }
            },
            "intermediates": intermediates,
            "travelMode": "DRIVE",
            "optimizeWaypointOrder": bool(optimize),
        }

        response = requests.post(
            "https://routes.googleapis.com/directions/v2:computeRoutes",
            headers={
                "Content-Type": "application/json",
                "X-Goog-Api-Key": self.server_key,
                "X-Goog-FieldMask": (
                    "routes.distanceMeters,"
                    "routes.duration,"
                    "routes.polyline.encodedPolyline,"
                    "routes.optimizedIntermediateWaypointIndex"
                ),
            },
            json=body,
            timeout=30,
        )
        response.raise_for_status()

        payload = response.json()
        routes = payload.get("routes", [])
        if not routes:
            return None

        route = routes[0]
        order = route.get(
            "optimizedIntermediateWaypointIndex",
            list(range(len(points))),
        )

        duration = route.get("duration", "0s")
        duration_seconds = 0
        if isinstance(duration, str) and duration.endswith("s"):
            try:
                duration_seconds = int(float(duration[:-1]))
            except Exception:
                pass

        return {
            "order": [int(i) for i in order],
            "distance_km": round(float(route.get("distanceMeters", 0)) / 1000, 2),
            "duration_minutes": int(round(duration_seconds / 60)),
            "polyline": (route.get("polyline") or {}).get("encodedPolyline"),
        }
