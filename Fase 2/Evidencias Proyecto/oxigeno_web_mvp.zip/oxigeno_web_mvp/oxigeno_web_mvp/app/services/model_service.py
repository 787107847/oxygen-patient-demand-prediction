from pathlib import Path
from datetime import date, timedelta
import math
import joblib
import numpy as np
import pandas as pd
from flask import current_app

MONTHS = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov"]

def range_from_days(days):
    days = int(max(1, round(float(days))))
    if days <= 5:
        return "Muy pronto"
    if days <= 8:
        return "Semanal"
    if days <= 15:
        return "Quincenal"
    if days <= 30:
        return "Mensual"
    return "Largo plazo"

class ModelService:
    def __init__(self):
        self.quantity_bundle = self._load(current_app.config["MODEL_QUANTITY"])
        self.timing_bundle = self._load(current_app.config["MODEL_TIMING"])
        self.cold_bundle = self._load(current_app.config["MODEL_COLD_START"])

    @staticmethod
    def _load(path):
        p = Path(path)
        if not p.exists():
            return None
        return joblib.load(p)

    @staticmethod
    def _first_predictor(bundle, keys):
        if bundle is None:
            return None

        if hasattr(bundle, "predict"):
            return bundle

        if isinstance(bundle, dict):
            for key in keys:
                obj = bundle.get(key)
                if hasattr(obj, "predict"):
                    return obj

        return None

    def status(self):
        return {
            "cantidad_historica": self.quantity_bundle is not None,
            "fecha_historica": self.timing_bundle is not None,
            "cold_start": self.cold_bundle is not None,
        }

    def predict(self, dataset_type, row):
        meses_historial = self._number(row.get("meses_activos"), 0)
        n_despachos = self._number(row.get("n_despachos"), 0)

        if dataset_type == "COLD_START":
            return self._predict_cold(row)

        quantity = (
            self._predict_historical_quantity(row)
            if meses_historial >= 3
            else self._predict_cold(row, only="quantity")
        )

        timing = (
            self._predict_historical_timing(row)
            if n_despachos >= 6
            else self._predict_cold(row, only="timing")
        )

        return {
            "quantity": quantity["quantity"],
            "days": timing["days"],
            "range": timing["range"],
            "confidence": timing.get("confidence"),
            "quantity_strategy": quantity["quantity_strategy"],
            "timing_strategy": timing["timing_strategy"],
            "quantity_model": quantity["quantity_model"],
            "timing_model": timing["timing_model"],
        }

    def _predict_cold(self, row, only=None):
        if self.cold_bundle is None:
            raise RuntimeError(
                "Falta models/modelo_cold_start.joblib."
            )

        features = pd.DataFrame([{
            "edad": self._number(row.get("edad"), np.nan),
            "sexo": str(row.get("sexo", "")).strip().upper(),
            "comuna": str(row.get("comuna", "")).strip().upper(),
        }])

        quantity_model = self._first_predictor(
            self.cold_bundle,
            ["modelo_cantidad", "quantity_model", "cold_quantity_model"],
        )
        time_regressor = self._first_predictor(
            self.cold_bundle,
            ["modelo_dias", "time_regressor", "cold_time_regressor"],
        )
        time_classifier = self._first_predictor(
            self.cold_bundle,
            ["time_classifier", "cold_time_classifier"],
        )

        result = {}

        if only in (None, "quantity"):
            if quantity_model is None:
                raise RuntimeError("El bundle Cold Start no contiene modelo de cantidad.")
            q = float(quantity_model.predict(features)[0])
            result.update({
                "quantity": int(max(0, round(q))),
                "quantity_strategy": "COLD_START",
                "quantity_model": type(quantity_model).__name__,
            })

        if only in (None, "timing"):
            if time_regressor is None:
                raise RuntimeError("El bundle Cold Start no contiene modelo de días.")
            days = int(max(1, round(float(time_regressor.predict(features)[0]))))

            confidence = None
            predicted_range = range_from_days(days)

            if time_classifier is not None:
                try:
                    predicted_range = str(time_classifier.predict(features)[0])
                    if hasattr(time_classifier, "predict_proba"):
                        confidence = float(
                            np.max(time_classifier.predict_proba(features)[0])
                        )
                except Exception:
                    pass

            result.update({
                "days": days,
                "range": predicted_range,
                "confidence": confidence,
                "timing_strategy": "COLD_START",
                "timing_model": type(time_regressor).__name__,
            })

        return result

    def _historical_quantity_features(self, row):
        vals = []
        for month in MONTHS:
            vals.append(self._number(row.get(month), 0.0))

        arr = np.asarray(vals, dtype=float)
        recent = arr[-3:] if len(arr) >= 3 else arr

        recent_trend = 0.0
        if len(recent) >= 2:
            x = np.arange(len(recent))
            recent_trend = float(np.polyfit(x, recent, 1)[0])

        return {
            "edad": self._number(row.get("edad"), np.nan),
            "age": self._number(row.get("edad"), np.nan),
            "sexo": str(row.get("sexo", "")).strip().upper(),
            "comuna": str(row.get("comuna", "")).strip().upper(),
            "target_month": 12,
            "mes_objetivo": 12,
            "lag_1": float(arr[-1]),
            "lag_2": float(arr[-2]),
            "lag_3": float(arr[-3]),
            "hist_mean": float(np.mean(arr)),
            "hist_median": float(np.median(arr)),
            "hist_std": float(np.std(arr)),
            "hist_min": float(np.min(arr)),
            "hist_max": float(np.max(arr)),
            "hist_sum": float(np.sum(arr)),
            "hist_nonzero_rate": float(np.mean(arr > 0)),
            "recent_trend": recent_trend,
            "months_observed": int(len(arr)),
        }

    def _predict_historical_quantity(self, row):
        model = self._first_predictor(
            self.quantity_bundle,
            [
                "model",
                "modelo",
                "final_model",
                "quantity_model",
                "modelo_cantidad",
                "production_model",
                "best_model",
            ],
        )

        if model is None:
            # Mantiene el sistema operativo sin fingir que se ejecutó ML.
            # Se usa Cold Start si falta el artefacto histórico.
            cold = self._predict_cold(row, only="quantity")
            cold["quantity_model"] = "COLD_START_FALLBACK_MODEL_NOT_AVAILABLE"
            return cold

        feature_values = self._historical_quantity_features(row)

        names = getattr(model, "feature_names_in_", None)
        if names is None and isinstance(self.quantity_bundle, dict):
            names = self.quantity_bundle.get("features")

        if names is None:
            frame = pd.DataFrame([feature_values])
        else:
            missing = [name for name in names if name not in feature_values]
            if missing:
                cold = self._predict_cold(row, only="quantity")
                cold["quantity_model"] = "COLD_START_FALLBACK_INCOMPATIBLE_FEATURES"
                return cold
            frame = pd.DataFrame(
                [{name: feature_values[name] for name in names}]
            )

        try:
            pred = float(model.predict(frame)[0])
            return {
                "quantity": int(max(0, round(pred))),
                "quantity_strategy": "HISTORICO",
                "quantity_model": type(model).__name__,
            }
        except Exception:
            cold = self._predict_cold(row, only="quantity")
            cold["quantity_model"] = "COLD_START_FALLBACK_PREDICTION_ERROR"
            return cold

    def _predict_historical_timing(self, row):
        """
        El modelo histórico de fecha creado previamente necesita intervalos
        recientes (lag_1..lag_5). dataset_completo_cruzado no contiene esos
        intervalos. Por eso:

        - si el CSV trae explícitamente lag_1..lag_5, se intenta el modelo;
        - de lo contrario, se usa intervalo_median como estimador histórico
          transparente, NO se presenta como una inferencia ML.
        """
        required_lags = [f"lag_{i}" for i in range(1, 6)]
        has_lags = all(
            key in row and row.get(key) is not None
            for key in required_lags
        )

        if has_lags and self.timing_bundle is not None:
            classifier = self._first_predictor(
                self.timing_bundle,
                ["classifier", "time_classifier", "modelo_clasificador"],
            )
            regressor = self._first_predictor(
                self.timing_bundle,
                ["regressor", "time_regressor", "modelo_regresor"],
            )

            feature_values = {
                "edad": self._number(row.get("edad"), np.nan),
                "sexo": str(row.get("sexo", "")).strip().upper(),
                "comuna": str(row.get("comuna", "")).strip().upper(),
                **{
                    key: self._number(row.get(key), np.nan)
                    for key in required_lags
                },
            }

            if regressor is not None:
                names = getattr(regressor, "feature_names_in_", None)
                if names is not None and all(n in feature_values for n in names):
                    frame = pd.DataFrame(
                        [{name: feature_values[name] for name in names}]
                    )
                    try:
                        days = int(
                            max(1, round(float(regressor.predict(frame)[0])))
                        )
                        confidence = None
                        label = range_from_days(days)

                        if classifier is not None:
                            label = str(classifier.predict(frame)[0])
                            if hasattr(classifier, "predict_proba"):
                                confidence = float(
                                    np.max(classifier.predict_proba(frame)[0])
                                )

                        return {
                            "days": days,
                            "range": label,
                            "confidence": confidence,
                            "timing_strategy": "HISTORICO",
                            "timing_model": type(regressor).__name__,
                        }
                    except Exception:
                        pass

        median = self._number(row.get("intervalo_median"), None)
        if median is not None and median > 0:
            days = int(max(1, round(median)))
            return {
                "days": days,
                "range": range_from_days(days),
                "confidence": None,
                "timing_strategy": "HISTORICO",
                "timing_model": "INTERVALO_MEDIAN_FALLBACK",
            }

        cold = self._predict_cold(row, only="timing")
        cold["timing_model"] = "COLD_START_FALLBACK_NO_INTERVAL_HISTORY"
        return cold

    @staticmethod
    def _number(value, default):
        try:
            if value is None or (isinstance(value, float) and math.isnan(value)):
                return default
            return float(value)
        except Exception:
            return default
