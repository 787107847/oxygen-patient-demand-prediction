import uuid
from flask_login import current_user

from ..db import call_proc, first_row
from ..security import (
    decrypt_json,
    decrypt_text,
    encrypt_json,
    encrypt_text,
    hmac_identifier,
)
from .maps_service import MapsService

class PatientService:
    def register_from_row(self, row, dataset_type):
        identifier_hash = hmac_identifier(row["id"])
        token_new = str(uuid.uuid4())

        address = row.get("direccion")
        location = None

        if address:
            try:
                location = MapsService().geocode(
                    address,
                    row.get("comuna"),
                )
            except Exception:
                location = None

        args = (
            token_new,
            identifier_hash,
            row.get("edad"),
            row.get("sexo"),
            row.get("comuna"),
            encrypt_text(row.get("nombre")),
            encrypt_text(row.get("apellido")),
            encrypt_text(row.get("contacto")),
            encrypt_text(address),
            encrypt_json(location),
            1,
            dataset_type,
            current_user.id_usuario,
        )

        _, sets = call_proc(
            "sp_paciente_registrar",
            args,
            role="vault",
        )

        result = first_row(sets)
        if not result:
            raise RuntimeError("La bóveda no devolvió token anónimo.")

        return result["token_anonimo"], location

    def secure_location(self, token):
        _, sets = call_proc(
            "sp_paciente_ubicacion_segura_obtener",
            (token, current_user.id_usuario),
            role="vault",
        )
        row = first_row(sets)
        if not row:
            return None

        return {
            "address": decrypt_text(row.get("direccion_enc")),
            "location": decrypt_json(row.get("ubicacion_enc")),
        }

    def unlink_identity(self, token):
        call_proc(
            "sp_paciente_desvincular_identidad",
            (token, current_user.id_usuario),
            role="vault",
        )
