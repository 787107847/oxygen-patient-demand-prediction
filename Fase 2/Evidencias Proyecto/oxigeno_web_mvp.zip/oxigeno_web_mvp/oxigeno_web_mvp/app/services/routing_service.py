from collections import defaultdict
from datetime import date
from ..db import call_proc
from .patient_service import PatientService
from .maps_service import MapsService

def chunks(items, size=25):
    for i in range(0, len(items), size):
        yield items[i:i + size]

class RoutingService:
    def __init__(self):
        self.patient_service = PatientService()
        self.maps = MapsService()

    def _all_patients(self):
        _, sets = call_proc("sp_pacientes_listar")
        return sets[0] if sets else []

    def _all_routes(self):
        _, sets = call_proc("sp_rutas_listar")
        return sets[0] if sets else []

    def generate_for_unrouted(self, planned_date, user_id):
        patients = [
            row
            for row in self._all_patients()
            if not row.get("id_ruta")
            and row.get("cantidad_mensual_estimada") is not None
            and row.get("comuna")
        ]

        by_comuna = defaultdict(list)
        for row in patients:
            by_comuna[row["comuna"]].append(row)

        existing = self._all_routes()
        max_number = defaultdict(int)
        for route in existing:
            comuna = route["comuna"]
            max_number[comuna] = max(
                max_number[comuna],
                int(route["numero_ruta_comuna"]),
            )

        created = []

        for comuna in sorted(by_comuna):
            for group in chunks(by_comuna[comuna], 25):
                number = max_number[comuna] + 1
                max_number[comuna] = number

                ordered_group, route_result = self._optimize(group)

                name = f"{comuna.title()} - Ruta {number}"

                out_args, _ = call_proc(
                    "sp_ruta_crear",
                    (
                        name,
                        comuna,
                        number,
                        planned_date,
                        user_id,
                        0,
                    ),
                )
                route_id = int(out_args[-1])

                for position, patient in enumerate(ordered_group, start=1):
                    call_proc(
                        "sp_ruta_agregar_paciente",
                        (
                            route_id,
                            patient["token_anonimo"],
                            position,
                            int(patient["cantidad_mensual_estimada"] or 0),
                        ),
                    )

                if route_result:
                    call_proc(
                        "sp_ruta_actualizar_metricas",
                        (
                            route_id,
                            route_result["distance_km"],
                            route_result["duration_minutes"],
                        ),
                    )

                created.append({
                    "id_ruta": route_id,
                    "nombre": name,
                    "comuna": comuna,
                    "pacientes": len(group),
                    "google_optimized": bool(route_result),
                })

        return created

    def _optimize(self, patients):
        points = []
        indexed = []

        for idx, patient in enumerate(patients):
            secure = self.patient_service.secure_location(
                patient["token_anonimo"]
            )
            loc = (secure or {}).get("location") or {}
            if "lat" in loc and "lng" in loc:
                points.append({
                    "lat": loc["lat"],
                    "lng": loc["lng"],
                    "token": patient["token_anonimo"],
                })
                indexed.append(idx)

        # Solo reordenamos si TODOS los pacientes tienen ubicación.
        if len(points) != len(patients):
            return patients, None

        try:
            route = self.maps.compute_route(points, optimize=True)
        except Exception:
            route = None

        if not route:
            return patients, None

        order = route["order"]
        return [patients[i] for i in order], route

    def route_map_data(self, route_id):
        _, sets = call_proc("sp_ruta_obtener", (route_id,))
        if not sets or not sets[0]:
            return None

        route = sets[0][0]
        details = sets[1] if len(sets) > 1 else []

        points = []
        for patient in details:
            secure = self.patient_service.secure_location(
                patient["token_anonimo"]
            )
            loc = (secure or {}).get("location") or {}

            if "lat" not in loc or "lng" not in loc:
                continue

            points.append({
                "token": patient["token_anonimo"],
                "lat": loc["lat"],
                "lng": loc["lng"],
                "address": (secure or {}).get("address"),
                "order": patient["orden_visita"],
                "cylinders": patient["cantidad_cilindros"],
            })

        route_result = None
        if points:
            try:
                route_result = self.maps.compute_route(
                    sorted(points, key=lambda x: x["order"]),
                    optimize=False,
                )
            except Exception:
                route_result = None

        return {
            "route": route,
            "points": points,
            "depot": self.maps.depot(),
            "polyline": route_result["polyline"] if route_result else None,
        }
