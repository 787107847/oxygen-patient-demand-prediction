Coloca aquí los artefactos entrenados:

- modelo_cantidad_cilindros.joblib
- modelo_proxima_entrega.joblib
- modelo_cold_start.joblib

Los nombres pueden cambiarse desde .env.

IMPORTANTE:
El modelo histórico de próxima fecha creado previamente usa intervalos recientes
(lag_1..lag_5). `dataset_completo_cruzado.csv` no contiene esos intervalos.
El backend intenta ese modelo únicamente si tales features están presentes.
Si no, utiliza `intervalo_median` como fallback histórico explícitamente marcado
como `INTERVALO_MEDIAN_FALLBACK`; no se presenta como inferencia ML.
