import base64
import secrets

print("FLASK_SECRET_KEY=" + secrets.token_urlsafe(48))
print("IDENTIFIER_HMAC_PEPPER=" + secrets.token_urlsafe(48))
print("DATA_ENCRYPTION_KEY=" + base64.b64encode(secrets.token_bytes(32)).decode("ascii"))
