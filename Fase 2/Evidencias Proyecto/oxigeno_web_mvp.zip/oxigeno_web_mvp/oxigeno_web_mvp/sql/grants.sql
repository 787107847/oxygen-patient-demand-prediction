-- Ejecutar DESPUÉS de crear manualmente los usuarios:
--   oxigeno_app@localhost
--   oxigeno_vault@localhost
--
-- Las contraseñas NO se incluyen en este archivo.
-- Créelas con phpMyAdmin > Cuentas de usuario o con SQL local introduciendo
-- una contraseña elegida por ti.

USE oxigeno_logistica;

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_usuario_crear TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_usuario_obtener_auth TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_usuario_registrar_login TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_usuario_cambiar_password TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_despacho_insertar TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_paciente_actualizar_resumen_historial TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_modelo_registrar TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_modelo_metrica_guardar TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_prediccion_guardar TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_importacion_crear TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_importacion_finalizar TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_ruta_crear TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_ruta_agregar_paciente TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_ruta_eliminar_paciente TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_ruta_actualizar_metricas TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_ruta_obtener TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_rutas_listar TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_pacientes_listar TO 'oxigeno_app'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_auditoria_registrar TO 'oxigeno_app'@'localhost';

GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_paciente_registrar TO 'oxigeno_vault'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_paciente_actualizar_ubicacion_segura TO 'oxigeno_vault'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_paciente_ubicacion_segura_obtener TO 'oxigeno_vault'@'localhost';
GRANT EXECUTE ON PROCEDURE oxigeno_logistica.sp_paciente_desvincular_identidad TO 'oxigeno_vault'@'localhost';

FLUSH PRIVILEGES;
