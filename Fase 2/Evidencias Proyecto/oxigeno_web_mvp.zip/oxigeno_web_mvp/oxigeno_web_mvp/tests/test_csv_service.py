import pandas as pd
from app.services.csv_service import detect_dataset_type

def test_cold_start_detection():
    df = pd.DataFrame(columns=["id", "edad", "comuna", "sexo"])
    assert detect_dataset_type(df) == "COLD_START"

def test_historical_detection():
    df = pd.DataFrame(columns=[
        "id", "edad", "comuna", "sexo",
        "suma_total", "meses_activos", "n_despachos", "intervalo_median",
        "ene", "feb", "mar",
    ])
    assert detect_dataset_type(df) == "HISTORICO"
