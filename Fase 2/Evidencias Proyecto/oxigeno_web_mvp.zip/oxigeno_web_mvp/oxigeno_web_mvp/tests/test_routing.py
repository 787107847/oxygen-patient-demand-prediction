from app.services.routing_service import chunks

def test_route_chunks_max_25():
    values = list(range(63))
    groups = list(chunks(values, 25))
    assert [len(x) for x in groups] == [25, 25, 13]
    assert all(len(x) <= 25 for x in groups)
